#include <Eigen/Eigen>
#include <Math/VECTOR.h>
#include <Physics/CONSTITUTIVE_MODEL.h>
#include <FEM/FEM_EXPORTER.h>
#include <Utils/STDCONTAINER.h>
#include <Utils/MESHIO.h>
#include <Utils/RANDOM.h>
#include <Utils/PROFILER.h>
#include <Utils/PARAMETER.h>
#include <Storage/prelude.hpp>
#include <Storage2/PRELUDE.hpp>
#include <pybind11/pybind11.h>

namespace py = pybind11;
namespace JGSL {

PYBIND11_MODULE(JGSL, m) {
    m.def("Kokkos_Initialize", &Kokkos_Initialize);
    m.def("Kokkos_Finalize", &Kokkos_Finalize);
    Export_Vector(m);
    Export_Random(m);
    py::module meshIO_m = m.def_submodule("MeshIO", "A submodule of JGSL for mesh IO");
    Export_MeshIO(meshIO_m);
    Export_StdContainer(m);
    Export_Constitutive_Model<double, 2>(m);
    Export_Constitutive_Model<double, 3>(m);
    py::module storage_m = m.def_submodule("Storage", "A submodule of JGSL for Storage");
    Export_Storage<Kokkos::Serial, Kokkos::HostSpace, 4>(storage_m);
    py::module storage_2_m = m.def_submodule("Storage2", "The newer version of Storage");
    Export_Storage_2(storage_2_m);
    Export_Profiler(m);
    py::module FEM_m = m.def_submodule("FEM", "A submodule of JGSL for FEM utils");
    Export_FEM(FEM_m);
    Export_SPARSE_MATRIX(m);
    PARAMETER::Export(m);


    m.def("Origami_SetHingeControls", [](py::list rows,int count) {
        if(count<0) throw std::runtime_error("invalid hinge count");
        std::vector<std::array<double,2>> staged(count,{0,0});
        for(auto item:rows) {
            auto row=py::cast<py::sequence>(item);
            if(row.size()!=3) throw std::runtime_error("hinge control requires id angle stiffness");
            int id=py::cast<int>(row[0]);double angle=py::cast<double>(row[1]),stiffness=py::cast<double>(row[2]);
            if(id<0 || id>=count || !std::isfinite(angle) || std::abs(angle)>3.141592653589794 || !std::isfinite(stiffness) || stiffness<=0 || staged[id][1]>0)
                throw std::runtime_error("invalid or duplicate hinge control");
            staged[id]={angle,stiffness};
        }
        origami_crease_controls.swap(staged);
    });
    m.def("Origami_GetHinges", [](MESH_NODE<double,3>& X,const std::vector<VECTOR<int,4>>& stencil) {
        py::list rows;
        for(size_t i=0;i<stencil.size();++i) {
            Eigen::Matrix<double,3,1> v[4];
            for(int j=0;j<4;++j)v[j]=Eigen::Matrix<double,3,1>(std::get<0>(X.Get_Unchecked(stencil[i][j])).data);
            double theta;Compute_Dihedral_Angle(v[0],v[1],v[2],v[3],theta);
            rows.append(py::make_tuple(i,py::make_tuple(stencil[i][0],stencil[i][1],stencil[i][2],stencil[i][3]),theta));
        }
        return rows;
    });
    m.def("Origami_ControlledHingeResponse", [](double theta,double rest,double coefficient,int edge) {
        auto r=Origami_Controlled_Hinge_Response(theta,rest,coefficient,edge);return py::make_tuple(r[0],r[1],r[2]);
    });
    m.def("Origami_SetGripAbsoluteTolerance", [](double tolerance) {
        if(!std::isfinite(tolerance)||tolerance<0) throw std::runtime_error("invalid absolute grip tolerance");
        origami_grip_absolute_tolerance=tolerance;
    });
    m.def("Origami_GripConverged", &Origami_GripConverged);
    m.def("Origami_SetMaxNewtonIterations", [](int limit) {
        if(limit<0) throw std::runtime_error("iteration limit must be nonnegative");
        origami_max_newton_iterations=limit;
    });
    m.def("Origami_CloneNodes", [](MESH_NODE<double,3>& X,MESH_NODE_ATTR<double,3>& attr) {
        MESH_NODE<double,3> copyX;MESH_NODE_ATTR<double,3> copyAttr;
        X.deep_copy_to(copyX);attr.deep_copy_to(copyAttr);
        return py::make_tuple(std::move(copyX),std::move(copyAttr));
    });
    m.def("Origami_GetPositions", [](MESH_NODE<double,3>& X) {
        py::list rows;
        X.Each([&](int id,auto data){auto &[x]=data;rows.append(py::make_tuple(x[0],x[1],x[2]));});
        return rows;
    });
    m.def("Origami_MakeGrips", [](py::dict targets,int vertexCount) {
        VECTOR_STORAGE<double,4> result;
        for(auto item:targets) {
            int id=py::cast<int>(item.first);auto values=py::cast<py::sequence>(item.second);
            if(id<0 || id>=vertexCount || values.size()!=3) throw std::runtime_error("invalid grip target");
            double x=py::cast<double>(values[0]),y=py::cast<double>(values[1]),z=py::cast<double>(values[2]);
            if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)) throw std::runtime_error("nonfinite grip target");
            result.Append(VECTOR<double,4>(id,x,y,z));
        }
        return result;
    });
    m.def("Origami_SetYieldMoment", [](double tau) {
        if(!std::isfinite(tau) || tau<0) throw std::runtime_error("yield moment must be finite and nonnegative");
        origami_yield_moment=tau;
    });
    m.def("Origami_HingeResponse", [](double delta,double coefficient) {
        auto r=Origami_Hinge_Response(delta,coefficient);
        return py::make_tuple(r[0],r[1],r[2]);
    });
    m.def("Origami_CommitPlasticity", [](MESH_NODE<double,3>& X,
        const std::vector<VECTOR<int,4>>& stencil,std::vector<VECTOR<double,3>>& info,
        MESH_ELEM_ATTR<double,2>& attr,double multiplier) {
        int changed=0; double dissipation=0;
        if(origami_yield_moment<=0 || !attr.size) return py::make_tuple(changed,dissipation);
        const double k=multiplier*std::get<FIELDS<MESH_ELEM_ATTR<double,3>>::P>(attr.Get_Unchecked(0))(0,0);
        auto staged=info;
        for(size_t e=0;e<stencil.size();++e) {
            Eigen::Matrix<double,3,1> v[4];
            for(int j=0;j<4;++j) v[j]=Eigen::Matrix<double,3,1>(std::get<0>(X.Get_Unchecked(stencil[e][j])).data);
            double theta; Compute_Dihedral_Angle(v[0],v[1],v[2],v[3],theta);
            double C=k*info[e][1]/info[e][2], delta=theta-info[e][0], y=origami_yield_moment/(2*C);
            // Guard angle branch ambiguity; do not silently cross a 2pi branch.
            if(std::abs(delta)>3.141592653589793) throw std::runtime_error("hinge angle branch exceeded");
            if(std::abs(delta)>y) {
                double plastic=std::copysign(std::abs(delta)-y,delta);
                staged[e][0]+=plastic;dissipation+=origami_yield_moment*std::abs(plastic);++changed;
            }
        }
        info.swap(staged);
        return py::make_tuple(changed,dissipation);
    });

}

}