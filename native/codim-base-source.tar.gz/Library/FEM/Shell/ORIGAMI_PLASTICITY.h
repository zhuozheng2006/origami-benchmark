#pragma once
#include <cmath>
#include <array>
#include <vector>
#include <stdexcept>
// Experimental perfect-plastic hinge. Default off. Units: N m per hinge.
// Reduced incremental potential: min_p C(delta-p)^2 + tau*|p|.
// Same ECI scalar law as libuipc stress-plastic shell bending (Apache-2.0),
// written independently here. Not a calibrated paper material law.
namespace JGSL {
inline double origami_yield_moment = 0.0;
// External rotational servo moments, separate from material plastic history.
inline std::vector<std::array<double,2>> origami_crease_controls;
inline int origami_max_newton_iterations = 0;
// Optional absolute L2 norm of all grip errors (m); zero retains upstream rule.
inline double origami_grip_absolute_tolerance = 0.0;
inline bool Origami_GripConverged(double error2,double residual,double newtonTol,int iterations) {
    return origami_grip_absolute_tolerance>0 && iterations>=4 &&
        std::isfinite(error2) && error2>=0 && std::isfinite(residual) && residual>=0 &&
        std::isfinite(newtonTol) && newtonTol>0 && residual<=newtonTol &&
        error2<=origami_grip_absolute_tolerance*origami_grip_absolute_tolerance;
}
template<class T> std::array<T,3> Origami_Hinge_Response(T delta,T coefficient) {
    if (!(coefficient > 0) || !std::isfinite(coefficient) || !std::isfinite(delta))
        throw std::runtime_error("invalid origami hinge input");
    const T tau = T(origami_yield_moment);
    if (tau <= 0 || T(2)*coefficient*std::abs(delta) <= tau)
        return {coefficient*delta*delta,T(2)*coefficient*delta,T(2)*coefficient};
    const T y=tau/(T(2)*coefficient);
    return {tau*(std::abs(delta)-y/T(2)),std::copysign(tau,delta),T(0)};
}
template<class T> std::array<T,3> Origami_Controlled_Hinge_Response(T theta,T rest,T coefficient,int edge) {
    auto r=Origami_Hinge_Response(theta-rest,coefficient);
    if(edge>=0 && size_t(edge)<origami_crease_controls.size()) {
        const auto control=origami_crease_controls[edge];
        const T d=std::remainder(theta-T(control[0]),T(6.283185307179586));
        const T k=T(control[1]);
        r[0]+=T(.5)*k*d*d;r[1]+=k*d;r[2]+=k;
    }
    return r;
}

}
