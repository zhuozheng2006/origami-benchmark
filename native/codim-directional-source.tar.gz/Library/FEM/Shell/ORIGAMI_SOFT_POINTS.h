#pragma once
#include <array>
#include <vector>
#include <cmath>
#include <stdexcept>
namespace JGSL {
// Target xyz, stiffness N/m, optional unit world normal. Zero normal means isotropic.
inline std::vector<std::array<double,7>> origami_soft_points;
inline std::array<double,3> Origami_Soft_Point_Response(double x,double target,double k,double h) {
    const double delta=x-target, coefficient=k*h*h;
    return {0.5*coefficient*delta*delta,coefficient*delta,coefficient};
}

inline std::array<double,13> Origami_Directional_Point_Response(const std::array<double,3>& x,const std::array<double,7>& c,double h) {
    std::array<double,13> result{};
    const double kh2=c[3]*h*h, norm2=c[4]*c[4]+c[5]*c[5]+c[6]*c[6];
    if(norm2==0) {
        for(int d=0;d<3;++d) {
            const double delta=x[d]-c[d];result[0]+=0.5*kh2*delta*delta;
            result[1+d]=kh2*delta;result[4+3*d+d]=kh2;
        }
    } else {
        double gap=0;for(int d=0;d<3;++d)gap+=(x[d]-c[d])*c[4+d];
        result[0]=0.5*kh2*gap*gap;
        for(int d=0;d<3;++d) {
            result[1+d]=kh2*gap*c[4+d];
            for(int j=0;j<3;++j)result[4+3*d+j]=kh2*c[4+d]*c[4+j];
        }
    }
    return result;
}

template<class T,int dim>
void Origami_Soft_Point_Energy(MESH_NODE<T,dim>& X,T h,T& energy) {
    if constexpr(dim==3) {
        if(origami_soft_points.empty())return;
        if(origami_soft_points.size()!=X.size)throw std::runtime_error("soft point count mismatch");
        for(int i=0;i<X.size;++i) {
            const auto& c=origami_soft_points[i];if(c[3]==0)continue;
            const auto& x=std::get<0>(X.Get_Unchecked(i));
            energy+=Origami_Directional_Point_Response({double(x[0]),double(x[1]),double(x[2])},c,h)[0];
        }
    }
}
template<class T,int dim>
void Origami_Soft_Point_Gradient(MESH_NODE<T,dim>& X,T h,MESH_NODE_ATTR<T,dim>& attr) {
    if constexpr(dim==3) {
        if(origami_soft_points.empty())return;
        if(origami_soft_points.size()!=X.size)throw std::runtime_error("soft point count mismatch");
        for(int i=0;i<X.size;++i) {
            const auto& c=origami_soft_points[i];if(c[3]==0)continue;
            const auto& x=std::get<0>(X.Get_Unchecked(i));auto& g=std::get<FIELDS<MESH_NODE_ATTR<T,dim>>::g>(attr.Get_Unchecked(i));
            auto response=Origami_Directional_Point_Response({double(x[0]),double(x[1]),double(x[2])},c,h);
            for(int d=0;d<3;++d)g[d]+=response[1+d];
        }
    }
}
template<class T,int dim>
void Origami_Soft_Point_Hessian(MESH_NODE<T,dim>& X,T h,std::vector<Eigen::Triplet<T>>& triplets) {
    if constexpr(dim==3) {
        if(origami_soft_points.empty())return;
        if(origami_soft_points.size()!=X.size)throw std::runtime_error("soft point count mismatch");
        for(int i=0;i<X.size;++i) {
            const auto& c=origami_soft_points[i];if(c[3]==0)continue;
            auto response=Origami_Directional_Point_Response({0,0,0},c,h);
            for(int d=0;d<3;++d)for(int j=0;j<3;++j)if(response[4+3*d+j]!=0)triplets.emplace_back(i*3+d,i*3+j,response[4+3*d+j]);
        }
    }
}
}
